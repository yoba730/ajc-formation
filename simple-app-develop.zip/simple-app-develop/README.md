# Simple Application
This is a simple `spring-boot` application for build demos

## License
Developed under [the MIT license](https://opensource.org/licenses/MIT).

